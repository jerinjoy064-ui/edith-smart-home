package com.edith.smarthome.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "edith_settings")

class DataStoreManager(private val context: Context) {
    companion object {
        val RELAY_1_NAME = stringPreferencesKey("relay_1_name")
        val RELAY_2_NAME = stringPreferencesKey("relay_2_name")
        val RELAY_3_NAME = stringPreferencesKey("relay_3_name")
        val RELAY_4_NAME = stringPreferencesKey("relay_4_name")
        val ESP32_IP = stringPreferencesKey("esp32_ip")
        val VOICE_PROFILE = stringPreferencesKey("voice_profile")
    }

    val relay1Name: Flow<String> = context.dataStore.data.map { it[RELAY_1_NAME] ?: "Living Room Light" }
    val relay2Name: Flow<String> = context.dataStore.data.map { it[RELAY_2_NAME] ?: "Bedroom Fan" }
    val relay3Name: Flow<String> = context.dataStore.data.map { it[RELAY_3_NAME] ?: "Kitchen Outlet" }
    val relay4Name: Flow<String> = context.dataStore.data.map { it[RELAY_4_NAME] ?: "Terrace Gateway" }
    val esp32Ip: Flow<String> = context.dataStore.data.map { it[ESP32_IP] ?: "192.168.4.1" }
    val voiceProfile: Flow<String> = context.dataStore.data.map { it[VOICE_PROFILE] ?: "Default Sir" }

    suspend fun saveRelayName(index: Int, name: String) {
        val key = when(index) {
            1 -> RELAY_1_NAME
            2 -> RELAY_2_NAME
            3 -> RELAY_3_NAME
            4 -> RELAY_4_NAME
            else -> RELAY_1_NAME
        }
        context.dataStore.edit { it[key] = name }
    }

    suspend fun saveEsp32Ip(ip: String) {
        context.dataStore.edit { it[ESP32_IP] = ip }
    }

    suspend fun saveVoiceProfile(profile: String) {
        context.dataStore.edit { it[VOICE_PROFILE] = profile }
    }
}
