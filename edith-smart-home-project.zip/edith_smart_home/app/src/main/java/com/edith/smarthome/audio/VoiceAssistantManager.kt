package com.edith.smarthome.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Calendar
import java.util.Locale

class VoiceAssistantManager(private val context: Context, private val onSpeakComplete: () -> Unit = {}) {
    private var tts: TextToSpeech? = null
    var isInitialized = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                isInitialized = true
                speakWelcome()
            }
        }
    }

    fun speak(text: String) {
        if (!isInitialized) return
        if (isQuietHours()) return // Respect quiet hours 23:00 - 07:00
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "EdithTTS")
    }

    fun speakForce(text: String) {
        if (!isInitialized) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "EdithTTSForce")
    }

    private fun speakWelcome() {
        speakForce("Welcome back Sir! I am EDITH, your personal AI assistant. All systems are online.")
    }

    private fun isQuietHours(): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hour >= 23 || hour < 7
    }

    fun checkHourlyAnnouncement() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        if (minute == 0 && !isQuietHours()) {
            val displayHour = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            speak("Sir, the time is $displayHour o'clock.")
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
