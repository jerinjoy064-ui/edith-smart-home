package com.edith.smarthome.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0B0F19)
val GlassSurface = Color(0x99161B26)
val GlassBorder = Color(0x33FFFFFF)
val NeonCyan = Color(0xFF00F0FF)
val NeonBlue = Color(0xFF0077FF)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val AccentRed = Color(0xFFFF3B30)
val AccentGreen = Color(0xFF34C759)
