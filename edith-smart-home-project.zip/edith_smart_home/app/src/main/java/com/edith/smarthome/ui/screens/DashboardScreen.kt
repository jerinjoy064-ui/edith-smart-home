package com.edith.smarthome.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edith.smarthome.audio.VoiceAssistantManager
import com.edith.smarthome.network.UdpClient
import com.edith.smarthome.ui.components.GlassCard
import com.edith.smarthome.ui.components.RelayControlCard
import com.edith.smarthome.ui.theme.AccentGreen
import com.edith.smarthome.ui.theme.AccentRed
import com.edith.smarthome.ui.theme.NeonCyan
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    relayNames: List<String>,
    udpClient: UdpClient,
    voiceManager: VoiceAssistantManager,
    onNavigateSettings: () -> Unit,
    onNavigateVoiceProfile: () -> Unit
) {
    var masterOn by remember { mutableStateOf(false) }
    var r1State by remember { mutableStateOf(false) }
    var r2State by remember { mutableStateOf(false) }
    var r3State by remember { mutableStateOf(false) }
    var r4State by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EDITH SMART HOME", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) },
                actions = {
                    IconButton(onClick = onNavigateVoiceProfile) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice Profile", tint = NeonCyan)
                    }
                    IconButton(onClick = onNavigateSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Master & Status Card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("MASTER POWER", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(if (masterOn) "SYSTEMS ACTIVE" else "SYSTEMS STANDBY", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Switch(
                            checked = masterOn,
                            onCheckedChange = { enabled ->
                                masterOn = enabled
                                r1State = enabled
                                r2State = enabled
                                r3State = enabled
                                r4State = enabled
                                scope.launch {
                                    udpClient.sendCommand(if (enabled) "MASTER_ON" else "MASTER_OFF")
                                }
                                voiceManager.speak(if (enabled) "Master systems activated." else "Master systems powered down.")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentGreen)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bluetooth, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BLE: edith | UDP: 4210/4211", fontSize = 12.sp)
                        }
                        Badge(containerColor = AccentGreen) {
                            Text("ONLINE", color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(4.dp))
                        }
                    }
                }
            }

            Text("ESP32-C3 RELAY CHANNELS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)

            RelayControlCard(
                relayName = relayNames.getOrElse(0) { "Relay 1" },
                isOn = r1State,
                onToggle = { state ->
                    r1State = state
                    scope.launch { udpClient.sendCommand(if (state) "RELAY_1_ON" else "RELAY_1_OFF") }
                }
            )
            RelayControlCard(
                relayName = relayNames.getOrElse(1) { "Relay 2" },
                isOn = r2State,
                onToggle = { state ->
                    r2State = state
                    scope.launch { udpClient.sendCommand(if (state) "RELAY_2_ON" else "RELAY_2_OFF") }
                }
            )
            RelayControlCard(
                relayName = relayNames.getOrElse(2) { "Relay 3" },
                isOn = r3State,
                onToggle = { state ->
                    r3State = state
                    scope.launch { udpClient.sendCommand(if (state) "RELAY_3_ON" else "RELAY_3_OFF") }
                }
            )
            RelayControlCard(
                relayName = relayNames.getOrElse(3) { "Relay 4" },
                isOn = r4State,
                onToggle = { state ->
                    r4State = state
                    scope.launch { udpClient.sendCommand(if (state) "RELAY_4_ON" else "RELAY_4_OFF") }
                }
            )

            // Voice Command simulation card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("EDITH VOICE INTERACTION", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Wake phrase: "Hey EDITH". MAX9814 & MAX98357A active.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            isListening = !isListening
                            if (isListening) {
                                voiceManager.speak("Listening for commands, Sir.")
                            } else {
                                voiceManager.speak("Voice standby.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isListening) AccentRed else NeonCyan)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isListening) "Listening (Tap to Stop)" else "Activate Voice Wake")
                    }
                }
            }
        }
    }
}
