package com.edith.smarthome

import android.app.Application

class EdithApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialization if needed
    }
}
