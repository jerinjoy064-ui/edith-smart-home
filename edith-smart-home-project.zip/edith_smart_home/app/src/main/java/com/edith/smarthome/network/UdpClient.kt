package com.edith.smarthome.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class UdpClient(private var targetIp: String, private val commandPort: Int = 4210, private val audioPort: Int = 4211) {

    fun updateIp(newIp: String) {
        targetIp = newIp
    }

    suspend fun sendCommand(message: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val socket = DatagramSocket()
            val address = InetAddress.getByName(targetIp)
            val data = message.toByteArray()
            val packet = DatagramPacket(data, data.size, address, commandPort)
            socket.send(packet)
            socket.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
