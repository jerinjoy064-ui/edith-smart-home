package com.edith.smarthome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.edith.smarthome.audio.VoiceAssistantManager
import com.edith.smarthome.data.DataStoreManager
import com.edith.smarthome.network.BleManager
import com.edith.smarthome.network.UdpClient
import com.edith.smarthome.ui.screens.DashboardScreen
import com.edith.smarthome.ui.screens.SettingsScreen
import com.edith.smarthome.ui.screens.VoiceProfileScreen
import com.edith.smarthome.ui.theme.EdithSmartHomeTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    private lateinit var dataStoreManager: DataStoreManager
    private lateinit var udpClient: UdpClient
    private lateinit var bleManager: BleManager
    private lateinit var voiceManager: VoiceAssistantManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataStoreManager = DataStoreManager(applicationContext)

        val initialIp = runBlocking { dataStoreManager.esp32Ip.first() }
        udpClient = UdpClient(initialIp)
        bleManager = BleManager(applicationContext)
        voiceManager = VoiceAssistantManager(applicationContext)

        setContent {
            EdithSmartHomeTheme {
                var currentScreen by remember { mutableStateOf("dashboard") }

                val r1 by dataStoreManager.relay1Name.collectAsState(initial = "Relay 1")
                val r2 by dataStoreManager.relay2Name.collectAsState(initial = "Relay 2")
                val r3 by dataStoreManager.relay3Name.collectAsState(initial = "Relay 3")
                val r4 by dataStoreManager.relay4Name.collectAsState(initial = "Relay 4")
                val relayNames = listOf(r1, r2, r3, r4)

                when (currentScreen) {
                    "dashboard" -> DashboardScreen(
                        relayNames = relayNames,
                        udpClient = udpClient,
                        voiceManager = voiceManager,
                        onNavigateSettings = { currentScreen = "settings" },
                        onNavigateVoiceProfile = { currentScreen = "voice_profile" }
                    )
                    "settings" -> SettingsScreen(
                        dataStoreManager = dataStoreManager,
                        onBack = { currentScreen = "dashboard" }
                    )
                    "voice_profile" -> VoiceProfileScreen(
                        dataStoreManager = dataStoreManager,
                        voiceManager = voiceManager,
                        onBack = { currentScreen = "dashboard" }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.shutdown()
    }
}
