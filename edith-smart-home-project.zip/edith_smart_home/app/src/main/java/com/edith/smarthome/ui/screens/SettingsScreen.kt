package com.edith.smarthome.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edith.smarthome.data.DataStoreManager
import com.edith.smarthome.ui.components.GlassCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    dataStoreManager: DataStoreManager,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    
    val r1 by dataStoreManager.relay1Name.collectAsState(initial = "Relay 1")
    val r2 by dataStoreManager.relay2Name.collectAsState(initial = "Relay 2")
    val r3 by dataStoreManager.relay3Name.collectAsState(initial = "Relay 3")
    val r4 by dataStoreManager.relay4Name.collectAsState(initial = "Relay 4")
    val ip by dataStoreManager.esp32Ip.collectAsState(initial = "192.168.4.1")

    var name1 by remember(r1) { mutableStateOf(r1) }
    var name2 by remember(r2) { mutableStateOf(r2) }
    var name3 by remember(r3) { mutableStateOf(r3) }
    var name4 by remember(r4) { mutableStateOf(r4) }
    var espIp by remember(ip) { mutableStateOf(ip) }
    var updateStatus by remember { mutableStateOf("Up to date (v1.0.0)") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EDITH SETTINGS", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("ESP32-C3 NETWORK CONFIG", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                    OutlinedTextField(
                        value = espIp,
                        onValueChange = { espIp = it },
                        label = { Text("ESP32 IP Address (UDP 4210/4211)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {
                        scope.launch { dataStoreManager.saveEsp32Ip(espIp) }
                    }) {
                        Text("Save IP Address")
                    }
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("EDIT RELAY LABELS", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                    
                    OutlinedTextField(value = name1, onValueChange = { name1 = it }, label = { Text("Relay 1 Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = name2, onValueChange = { name2 = it }, label = { Text("Relay 2 Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = name3, onValueChange = { name3 = it }, label = { Text("Relay 3 Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = name4, onValueChange = { name4 = it }, label = { Text("Relay 4 Name") }, modifier = Modifier.fillMaxWidth())

                    Button(onClick = {
                        scope.launch {
                            dataStoreManager.saveRelayName(1, name1)
                            dataStoreManager.saveRelayName(2, name2)
                            dataStoreManager.saveRelayName(3, name3)
                            dataStoreManager.saveRelayName(4, name4)
                        }
                    }) {
                        Text("Save Relay Names")
                    }
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("SYSTEM & APP UPDATE", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                    Text(updateStatus, fontSize = 14.sp)
                    Button(onClick = {
                        updateStatus = "Checked GitHub: Latest Version v1.0.0 installed."
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Check for GitHub Updates")
                    }
                }
            }
        }
    }
}
